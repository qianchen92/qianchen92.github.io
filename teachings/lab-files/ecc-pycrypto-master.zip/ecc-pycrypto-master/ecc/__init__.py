# We shouldn't do versioning. We should roll.
__version__ = "1.0.0"  # noqa
